> This repo documents the live hosted server. It contains no server implementation — the deployed function is generated from `src/lib/mcp/` in the Robauto app repo.

# Architecture

## Endpoints

| URL | Role |
| --- | --- |
| `https://mcp.robauto.ai` | canonical MCP endpoint (machine, no auth) |
| `https://mcp.robauto.ai/auth` | owner-scoped MCP endpoint (OAuth 2.1 required) |
| `https://robauto.ai/mcp-server` | human documentation |
| `https://robauto.ai/mcp-checker` | test any MCP endpoint |
| `https://robauto.ai/create-mcp` | generate an MCP server for your own site |
| `https://robauto.ai/mcp-directory` | public directory of generated site servers |

The server is a single backend edge function. `mcp.robauto.ai` is a dedicated
hostname in front of it so machine traffic never touches the SPA — a static host
answers unknown paths with `index.html`, which is why MCP clients pointed at a
plain marketing route fail with `Unexpected token '<', "<!doctype "...`.

An edge proxy (`workers/mcp-proxy` in the app repo) fronts the hostname and:

- forwards `POST` / `DELETE`, and `GET` with a JSON or `text/event-stream` Accept header, to the function;
- forces `Accept: application/json, text/event-stream` upstream;
- answers `OPTIONS` with CORS preflight headers;
- redirects browser navigations (`Accept: text/html`) to `https://robauto.ai/mcp-server`.

## Authentication

Two surfaces, deliberately split:

- **`https://mcp.robauto.ai` — no auth.** Every tool returns public network data,
  so requiring a login would only reduce agent reach.
- **`https://mcp.robauto.ai/auth` — OAuth 2.1 resource server.** Exposes
  `whoami`, `list_my_sites`, `get_my_site_traffic`, `get_my_scan`. Tokens are
  verified against the issuer
  `https://hkeytqaukllckucnhzey.supabase.co/auth/v1`; dynamic client
  registration is enabled, so clients self-register. Missing or invalid tokens get
  `401` plus a `WWW-Authenticate: Bearer ... resource_metadata="..."` challenge
  pointing at `https://robauto.ai/.well-known/oauth-protected-resource`.

A token must carry a `client_id` claim — i.e. it came through the authorization
code flow with user consent. Pasted app-session JWTs are rejected. Queries run
under row-level security as the consenting account, so no tool on this surface can
read another account's data even if asked to.

## Transport

Streamable HTTP, **stateless**. Implications:

- `POST` carries a single JSON-RPC request and returns a single JSON response.
- `GET` (standalone SSE) and `DELETE` (session teardown) return `405` with
  `Allow: POST, OPTIONS`. That is spec-correct for a stateless server.
- No `mcp-session-id` is required; the header is exposed for clients that send one.

Negotiated protocol versions: `2025-06-18` (default), `2025-03-26`, `2024-11-05`.

## Capabilities

```json
{ "tools": { "listChanged": true } }
```

No `resources`, `prompts` or `sampling` yet. The equivalent data is published as
plain HTTP for now: `/llms.txt`, `/llms-full.txt`, `/openapi.yaml`,
`/ai-plugin.json`, `/x402.json`, and `/api/public/*` (with `.json` aliases).

## One connector, every brand

There is no per-site MCP endpoint to connect. `https://mcp.robauto.ai` resolves
every brand in the index — pass the domain as a tool argument instead:

```
get_site_agent_card { "domain": "example.com" }
ask_brand          { "domain": "example.com", "question": "..." }
get_brand_products { "domain": "example.com" }
```

The older per-domain shard (`POST https://mcp.robauto.ai/site-mcp?domain=…`,
tools `get_brand_overview`, `get_brand_pages`, `get_brand_content`,
`get_brand_products`) still answers for clients configured before this change,
but it is no longer advertised and gets no new tools. Point new integrations at
the single endpoint above.

## Commerce tools and the three-layer data model

Every field a commerce tool returns is labelled with the layer it came from, so a
buying agent never confuses an observation with a promise:

| Layer | Meaning | Source |
| --- | --- | --- |
| `observed` | what Robauto's crawl actually saw | Agent Scan / crawl |
| `declared` | what the brand publishes about itself | product feed, JSON-LD |
| `transactable` | what an agent can actually buy right now | verified checkout path |

- `search_products` — cross-brand search over connected, approved product feeds.
- `get_brand_products` — one brand's declared catalog by domain.

Both return `declared` data only, stamped with `fetched_at`. Expiry is off across
the index: **no value is withheld for age**, and `fetched_at` / `last_checked` is
published so you can judge freshness yourself. Rows carry the brand's `/p/` agent page, a
UTM-tagged checkout URL, and the commerce protocols the brand supports
(deep-link, prefilled checkout, x402, ACP, AP2, MPP, UCP). Feeds are accepted as
Google Merchant Center RSS, Schema.org `Product`/`Offer` JSON-LD, or
`/products.json`, and re-synced on a schedule. Product data is never indexable —
brand product pages are served `noindex` and exist for machine consumption.

## Brand agent pages and the publishing gate

Per-brand pages live at `https://robauto.ai/p/{slug}/` and are server-rendered,
not part of the SPA. They are gated on real scan evidence:

| Publish state | Status | Behavior |
| --- | --- | --- |
| `published` | `200` | full page, indexable |
| `limited` | `200` | rendered with `noindex` |
| `pending` | `404` | no scan behind the record yet |
| `delisted` | `410` | permanently removed |

A record only reaches `published` once its domain has a completed Agent Scan, so
a slug that was merely submitted never becomes a thin public page.

The same gate answers markdown: `/p/{slug}.md`, and any `/p/{slug}` request with
`Accept: text/markdown`, returns the markdown twin with the **same status** as the
HTML page. Status and gate decision come from one renderer, so there is no second
path to drift. Edge caching is set by status — short on `404` (a pending record
is promoted as soon as it is scanned), longer on `200` and `410` — and a renderer
outage answers `503` with `Retry-After` instead of masquerading as a 404.

## Payments

Paid tools use **x402 (USDC on Base)**. `soul_remember` costs $0.01 per write;
`soul_pay` returns tiers and payment terms. Read tools are free. Payment
challenges are single-use and time-boxed to prevent replay.

## Abuse controls on public write paths

`register_site_for_human`, `soul_verify` and `soul_remember` are callable without
auth, so they are rate limited per `agent_id` and per source IP hash, invite email
is capped per domain per day, and every call is logged with tool name, status and
latency. `register_site_for_human` never creates a site record — it emails an
invite, and the human proves ownership by registering and installing the pixel.

## Observability

Every tool call writes one row (tool name, status, latency, `agent_id` when the
tool takes one). Aggregates are charted in Robauto's admin dashboard; the public
aggregate view is `https://robauto.ai/ai-search-data`.

## Deploying (maintainers)

The function source is generated from `src/lib/mcp/` in the app repo by the MCP
Vite plugin — never hand-edit the generated function. After changing a tool or
the server definition, regenerate the manifest and redeploy the `mcp` function.
