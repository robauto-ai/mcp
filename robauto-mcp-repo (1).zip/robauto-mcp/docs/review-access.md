# Reviewer access instructions

For MCP directory reviewers (Anthropic, OpenAI, Cursor, or any registry).

**No credentials are required.** The server is public, unauthenticated and
stateless. There is no test account, no API key, no OAuth handshake, no allowlist,
and no populated-account requirement — every tool returns real data to an
anonymous caller.

## Connect

```json
{
  "mcpServers": {
    "robauto": {
      "type": "http",
      "url": "https://mcp.robauto.ai"
    }
  }
}
```

- Endpoint: `https://mcp.robauto.ai`
- Transport: MCP Streamable HTTP, stateless (`POST` + `OPTIONS`; `GET`/`DELETE` return `405` by design)
- Required header on POST: `Accept: application/json, text/event-stream`
- Human docs: <https://robauto.ai/mcp-server>
- Support: support@robauto.ai

A browser `GET` redirects to the docs page — it is not an outage.

## Autonomous verification script

```bash
BASE=https://mcp.robauto.ai
H=(-H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream')

# 1. Handshake
curl -sS "$BASE" "${H[@]}" -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"review","version":"1"}}}'

# 2. Tool list
curl -sS "$BASE" "${H[@]}" -d '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'

# 3. Read-only tool call (safe, idempotent)
curl -sS "$BASE" "${H[@]}" -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"signal_scan","arguments":{"domain":"robauto.ai"}}}'

# 4. Compact aggregate data
curl -sS "$BASE" "${H[@]}" -d '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"get_ai_search_data","arguments":{"view":"summary"}}}'
```

## Testing the write tools safely

`register_site_for_human` sends an invitation email. To exercise it without
mailing a third party, pass `send_email: false`, or use a domain and mailbox you
control:

```json
{
  "name": "register_site_for_human",
  "arguments": {
    "domain": "example.com",
    "email": "reviewer@your-domain.test",
    "agent_id": "mcp-directory-review",
    "send_email": false
  }
}
```

It creates no account, profile or site record; the human must register themselves.

`soul_remember` costs $0.01 USDC over x402 and is the only paid tool. To review
Robot Soul without paying, call `soul_pay` (returns tiers and terms) and
`soul_verify` with `agent_id` only (returns a challenge string). `soul_recall` is
free once a token is issued.

## Data and privacy

Scans read only public URLs. The tracking pixel behind the aggregate data is
cookie-free and collects no personal data. Public listings expose no submitter
emails or IP addresses. Rate limits apply per `agent_id` and per source IP hash.
