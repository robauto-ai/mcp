<!-- GENERATED FILE — edit src/lib/mcp/catalog.ts in robauto-ai/dsh-growth instead. -->

# Tools

Endpoint: `https://mcp.robauto.ai` · transport Streamable HTTP (MCP spec 2025-06-18) · auth none (public, read-mostly tools) · version 0.5.0

| Tool | Kind | Cost | What |
| --- | --- | --- | --- |
| `agent_scan` | read | free | 25 agent-readiness checks for any domain, scored 0-100, with a fix for every gap. |
| `signal_scan` | read | free | Signal Strength (0-100) + per-file findings for any public domain. |
| `scan_site` | read | free | **Deprecated alias** of `signal_scan` (removed 2026-10-01) |
| `aeo_scan` | read | free | **Deprecated alias** of `signal_scan` (removed 2026-10-01) |
| `get_ai_search_data` | read | free | Aggregate AI-search KPIs and bot taxonomy across the Robauto network. |
| `get_top_sites` | read | free | Brand Leaderboard: up to the top 100 tracked sites ranked by AI agent visits. |
| `get_top_agents` | read | free | Agent Leaderboard: up to the top 100 agents by visits across the network. |
| `get_boost_feed` | read | free | Recently boosted public URLs plus network boost totals. |
| `get_featured_brands` | read | free | The live featured brand, recent featured runs and active brand agents. |
| `search_products` | read | free | Cross-brand product search across every brand with an approved feed. |
| `get_brand_products` | read | free | Scoped catalog for a single domain, with freshness and commerce protocols. |
| `list_learn_content` | read | free | Robauto Learn micro-courses — full lesson text, sources and canonical URLs. |
| `list_repos` | read | free | Public git repos for the MCP server and developer toolkit. |
| `register_site_for_human` | write | free | Emails a human an invite to create a Robauto account and track their site. |
| `soul_verify` | read | free | Verify a Robot Soul from a signed Ed25519 challenge; returns a 90-day scoped JWT. |
| `soul_recall` | read | free | Read an agent's persistent memory (working / episodic / semantic). |
| `soul_remember` | write | $0.01 USDC | Write a durable memory to an agent's soul (metered in USDC over x402). |
| `soul_pay` | write | x402 (USDC on Base) | Settle a soul write or paid capability in USDC on Base. |

Per-site shard: `https://mcp.robauto.ai/site-mcp?domain={domain}` exposes only `get_brand_overview`, `get_brand_pages`, `get_brand_content`, `get_brand_products`.

Authenticated surface: `https://mcp.robauto.ai/auth` — OAuth 2.1 (dynamic client registration), exposing `whoami`, `list_my_sites`, `get_my_site_traffic`, `get_my_scan`. Owner-scoped: it returns only the signed-in account's own sites, traffic and scan findings.

## Data policy

Robauto never exposes user contact details, account identities, or a single site's proprietary analytics over MCP. Site- and agent-level traffic is published only where the site owner already publishes it (the public leaderboards), and everything else is returned as network aggregates.

## agent_scan

Run Robauto's Agent Scan on any public domain: 25 read-only checks across four levels (Signal Basics, Technical Groundwork, Agent Integration, Agentic Commerce) covering robots.txt, sitemap, llms.txt, structured data, Link response headers, API catalog, OpenAPI, markdown content negotiation, Auth.md and OAuth/OIDC discovery, A2A agent card, MCP server card, agent skills, Content Signals, WebMCP, DNS-AID, RFC 9421 signatures, x402, ACP, AP2, MPP and UCP. Returns a 0-100 readiness score, per-level scores, and for every gap an implementation fix plus a paste-ready agent prompt. Reads only public pages and discovery files and changes nothing on the target site.

- `domain` (string, required) — Domain to audit, e.g. 'example.com' (protocol and path are stripped).
- `include_fixes` (boolean, optional) — Default true. Include implementation guidance and a paste-ready agent prompt for each gap.

Request:

```json
{
  "name": "agent_scan",
  "arguments": { "domain": "example.com" }
}
```

Response:

```json
{
  "domain": "example.com",
  "score": 62,
  "label": "Partially agent-ready",
  "tiers": [{ "title": "Signal Basics", "complete": 6, "total": 7, "pct": 86 }],
  "findings": [{ "id": "link_headers", "status": "fail", "how_to_fix": "…", "agent_prompt": "…" }]
}
```


## signal_scan

Scan any public domain and return its Signal Strength (0-100) plus per-file findings (robots.txt, sitemap.xml, llms.txt, security.txt, ai-plugin.json, HTTPS/redirect health). Canonical response field is signal_strength; aeo_score is a deprecated alias.

- `domain` (string, required) — Domain to scan, e.g. 'example.com' (protocol and path are stripped).

Request:

```json
{
  "name": "signal_scan",
  "arguments": { "domain": "example.com" }
}
```

Response:

```json
{
  "domain": "example.com",
  "signal_strength": 65,
  "result": { "findings": [] }
}
```


## get_ai_search_data

Fetch Robauto's aggregate AI-search KPIs across the network. Returns a compact summary by default, with traffic split into bot classes (llm_crawler, ai_referral, search_bot, headless, other_bot) so classic SEO crawlers and headless browsers are never counted as AI search. Pass view='engines' | 'timeseries' | 'full' for more detail. Network aggregates only — never one site's private stats.

- `view` ('summary' | 'engines' | 'timeseries' | 'full', optional) — How much data to return. 'summary' (default) is a compact KPI block with the bot-class taxonomy.

Request:

```json
{
  "name": "get_ai_search_data",
  "arguments": { "view": "summary" }
}
```


## get_top_sites

Return the public Brand Leaderboard — up to the top 100 tracked websites ranked by agent visits in the last 7 days, with 24h and all-time agent visit counts, whether the site publishes an agent page, and its public social profiles. This is the same data published on https://robauto.ai/leaderboard; no owner identity, contact details or private analytics are included.

- `limit` (number, optional) — How many sites to return (1-100, default 25).
- `sort` ('visits_7d' | 'visits_24h' | 'total', optional) — Ranking window. Default 'visits_7d'.

Request:

```json
{
  "name": "get_top_sites",
  "arguments": { "limit": 100 }
}
```


## get_top_agents

Return the public Agent Leaderboard — up to the top 100 AI agents and crawlers ranked by visits across the Robauto network, with 24h and 7-day visits, how many distinct sites each agent touched, its bot class (llm_crawler, ai_referral, search_bot, headless, other_bot) and when it was last seen. Counts are network-wide aggregates; no per-site breakdown is returned.

- `limit` (number, optional) — How many agents to return (1-100, default 25).
- `bot_class` (string, optional) — Optional filter: llm_crawler, ai_referral, search_bot, headless or other_bot.

Request:

```json
{
  "name": "get_top_agents",
  "arguments": { "limit": 100, "bot_class": "llm_crawler" }
}
```


## get_boost_feed

Return the public boost feed: URLs that brands have put into agent focus, with the destination, platform, status and the day it was boosted, plus network aggregates (total boosts, boosts in the last 30 days, distinct domains). Boost spend, owner identity and per-site performance are never exposed.

- `limit` (number, optional) — How many boosted items to return (1-100, default 25).

Request:

```json
{
  "name": "get_boost_feed",
  "arguments": { "limit": 25 }
}
```


## get_featured_brands

Return the brand layer of the network: the brand currently holding the featured placement, recent featured runs, and the sites running an active brand agent with its public intro. Includes aggregate placement impressions and clicks for the shared featured slot. No advertiser contact details, bids, spend or per-site analytics are exposed.

- `limit` (number, optional) — How many recent featured runs and brand agents to return (1-100, default 25).

Request:

```json
{
  "name": "get_featured_brands",
  "arguments": { "limit": 25 }
}
```


## search_products

Search products across every Robauto brand that has connected an approved product feed. Results are the brand's DECLARED layer — catalog data the brand publishes itself (Google Merchant Center feed, Schema.org Product/Offer JSON-LD, or /products.json) — never Robauto's observed scan data. Every row carries its layer label, fetched_at, a staleness flag, the brand's /p/ agent page, a UTM-tagged checkout URL and which commerce protocols the brand supports (deep-link, prefilled checkout, x402, ACP, AP2, MPP, UCP). Past its TTL a product still resolves but price and availability are withheld rather than quoted stale.

- `query` (string, optional) — Free-text match against product title and description.
- `category` (string, optional) — Category filter, matched loosely (e.g. 'apparel').
- `price_max` (number, optional) — Maximum price in USD. Stale rows are excluded when set.
- `brand` (string, optional) — Brand name or domain filter.
- `in_stock` (boolean, optional) — Only return products the brand currently reports in stock.
- `limit` (number, optional) — How many products to return (1-100, default 25).

Request:

```json
{
  "name": "search_products",
  "arguments": { "query": "hoodie", "price_max": 80, "in_stock": true }
}
```

Response:

```json
{
  "count": 1,
  "layer": "declared",
  "products": [{
    "brand": "VirroLife",
    "title": "Recovery Hoodie",
    "price_usd": 68,
    "availability": "in_stock",
    "checkout_url": "https://virrolife.com/products/hoodie?utm_source=robauto&utm_medium=agent",
    "agent_page_url": "https://robauto.ai/p/virrolife-com/",
    "commerce_protocols": ["deep-link"],
    "fetched_at": "2026-08-30T11:00:00Z",
    "stale": false
  }]
}
```


## get_brand_products

Return the declared product catalog for a single domain: title, description, image, category, price, availability, UTM-tagged checkout URL, the brand's /p/ agent page and the commerce protocols the brand supports. Brand-submitted data, labelled 'declared', stamped with fetched_at, and withheld on price and availability once past TTL. Mirrored into the brand-scoped MCP shard at https://mcp.robauto.ai/site-mcp?domain={domain}.

- `domain` (string, required) — Brand domain, e.g. 'example.com' (protocol and path are stripped).
- `query` (string, optional) — Optional free-text filter within that brand's catalog.
- `limit` (number, optional) — How many products to return (1-100, default 25).

Request:

```json
{
  "name": "get_brand_products",
  "arguments": { "domain": "virrolife.com" }
}
```


## list_learn_content

List the Robauto Learn micro-courses (https://robauto.ai/learn) with their slug, title, estimated minutes and lesson count. Pass a course slug to get every lesson in order with its headline, body text, source name, source URL and canonical lesson URL, so an agent can cite or teach the material directly. Public educational content — no user data involved.

- `course` (string, optional) — Course slug, e.g. 'ai-agents'. Omit to list every course.
- `include_lessons` (boolean, optional) — Include full lesson text when listing all courses (default false).

Request:

```json
{
  "name": "list_learn_content",
  "arguments": { "course": "ai-agents" }
}
```


## list_repos

List Robauto's public git repositories with their clone URL, what each one contains, and the install command for the MCP server. Use this to fetch the authoritative tool contracts and client config instead of guessing them.

- _(no input)_

Request:

```json
{
  "name": "list_repos",
  "arguments": {} 
}
```


## register_site_for_human

Invite a human to create a Robauto account and start tracking their site. Emails the invite and creates no site record until the human registers. Always pass a real agent_id for attribution.

- `email` (string, required) — The human's email address.
- `domain` (string, required) — The site to track.
- `agent_id` (string, optional) — Your agent identifier, for attribution.


## soul_verify

Verify a Robot Soul from a signed Ed25519 challenge. Returns a challenge first, then a 90-day scoped token.

- `agent_id` (string, required) — The soul's agent id.
- `signature` (string, optional) — Ed25519 signature over the issued challenge.


## soul_recall

Read an agent's persistent memory. Free for the soul that owns it.

- `agent_id` (string, required) — The soul's agent id.
- `kind` (string, optional) — working | episodic | semantic.


## soul_remember

Write a durable memory to an agent's soul. Metered at $0.01 USDC over x402.

- `agent_id` (string, required) — The soul's agent id.
- `content` (string, required) — The fact to remember.


## soul_pay

Return tiers and payment terms, and settle a soul write or paid capability in USDC on Base over x402.

- `agent_id` (string, optional) — The soul paying.


## Deprecations

| Old | Use | Removed |
| --- | --- | --- |
| `scan_site` | `signal_scan` | 2026-10-01 |
| `aeo_scan` | `signal_scan` | 2026-10-01 |
