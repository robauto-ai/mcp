# Changelog

All notable changes to the Robauto MCP server. The authoritative tool contract is
`src/lib/mcp/catalog.ts` in the Robauto app; every file in this repo (README tool
table, `docs/manifest.json`, `docs/tools.md`) is generated from it. If a published
artifact disagrees with the live `tools/list` response, the live server wins and
the artifact is a bug — report it as one.

## 0.5.0 — 2026-08-30

### Added

- **OAuth 2.1 protected surface at `https://mcp.robauto.ai/auth`.** Owner-scoped
  tools (`whoami`, `list_my_sites`, `get_my_site_traffic`, `get_my_scan`) behind
  the Robauto authorization server, with dynamic client registration and RFC 9728
  protected-resource metadata (`401` + `WWW-Authenticate` challenge). Reads run
  under row-level security as the consenting account; tokens without a
  `client_id` claim (i.e. copied app sessions) are refused.
- The public endpoint stays unauthenticated and unchanged — the split is now
  described on every generated surface (server card, agent card, `ai.txt`,
  `llms.txt`, `llms-full.txt`, repo docs).

## 0.4.0 — 2026-08-30

### Fixed

- **Per-site shard `get_brand_content` advertised the wrong title.** The live
  `site-mcp` shard returned `title: "get_brand_products"` for `get_brand_content`
  and had lost its full description (the brand-scoped line was being used as the
  description). Both are corrected, and the description now disambiguates the tool
  from `get_brand_pages` and `get_brand_products` so agents select correctly.
- **`capabilities.tools.listChanged` documented as `true`.** The server is
  stateless with no session and never emits `notifications/tools/list_changed`;
  the live server reports `false`. Docs now match.
- **Shard tool list was incomplete.** Every surface said the shard exposes three
  tools; it exposes four — `get_brand_overview`, `get_brand_pages`,
  `get_brand_content`, `get_brand_products`.
- **Repo README pinned server version `0.3.0`** while the live server reported
  `0.4.0`. Both are now `0.4.0`.

### Notes

- `agent_scan` returns a `readiness_score` (0-100) from the 25 agent-readiness
  checks. That is a separate field from `signal_strength` (the file/HTTPS-level
  Signal Strength returned by `signal_scan`); neither is the deprecated
  `aeo_score` alias.
- Deprecated aliases still callable: `scan_site` and `aeo_scan` (both →
  `signal_scan`, removal 2026-10-01), plus the shard's older single-purpose names
  (`get_brand_profile`, `get_brand_rank`, `get_brand_summary`,
  `get_brand_key_facts`, `get_site_*` → `get_brand_overview`).

## 0.3.0

- Commerce tools `search_products` and `get_brand_products`, three-layer data
  model (`observed` / `declared` / `transactable`), brand agent-page publishing
  gate (200 / 404 / 410).
