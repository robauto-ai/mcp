> This repo documents the live hosted server. It contains no server implementation — the deployed function is generated from `src/lib/mcp/` in the Robauto app repo.

# Architecture

## Endpoints

| URL | Role |
| --- | --- |
| `https://mcp.robauto.ai` | canonical MCP endpoint (machine) |
| `https://robauto.ai/mcp-server` | human documentation |
| `https://robauto.ai/mcp-checker` | test any MCP endpoint |
| `https://robauto.ai/create-mcp` | generate an MCP server for your own site |
| `https://robauto.ai/mcp-directory` | public directory of generated site servers |

The server is a single backend edge function. `mcp.robauto.ai` is a dedicated
hostname in front of it so machine traffic never touches the SPA — a static host
answers unknown paths with `index.html`, which is why MCP clients pointed at a
plain marketing route fail with `Unexpected token '<', "<!doctype "...`.

An edge proxy (`workers/mcp-proxy` in the app repo) fronts the hostname and:

- forwards `POST` / `DELETE`, and `GET` with a JSON or `text/event-stream` Accept header, to the function;
- forces `Accept: application/json, text/event-stream` upstream;
- answers `OPTIONS` with CORS preflight headers;
- redirects browser navigations (`Accept: text/html`) to `https://robauto.ai/mcp-server`.

## Transport

Streamable HTTP, **stateless**. Implications:

- `POST` carries a single JSON-RPC request and returns a single JSON response.
- `GET` (standalone SSE) and `DELETE` (session teardown) return `405` with
  `Allow: POST, OPTIONS`. That is spec-correct for a stateless server.
- No `mcp-session-id` is required; the header is exposed for clients that send one.

Negotiated protocol versions: `2025-06-18` (default), `2025-03-26`, `2024-11-05`.

## Capabilities

```json
{ "tools": { "listChanged": true } }
```

No `resources`, `prompts` or `sampling` yet. The equivalent data is published as
plain HTTP for now: `/llms.txt`, `/llms-full.txt`, `/openapi.yaml`,
`/ai-plugin.json`, `/x402.json`, and `/api/public/*` (with `.json` aliases).

## Per-site MCP shards

Sites generated through `/create-mcp` are served by a separate function keyed by
domain:

```
POST https://mcp.robauto.ai/site-mcp?domain=example.com
```

Tools: `get_site_signal`, `get_site_summary`, `get_site_key_facts`. Content comes from a moderated
crawl summary; unpublished or rejected submissions return an error result.

## Payments

Paid tools use **x402 (USDC on Base)**. `soul_remember` costs $0.01 per write;
`soul_pay` returns tiers and payment terms. Read tools are free. Payment
challenges are single-use and time-boxed to prevent replay.

## Abuse controls on public write paths

`register_site_for_human`, `soul_verify` and `soul_remember` are callable without
auth, so they are rate limited per `agent_id` and per source IP hash, invite email
is capped per domain per day, and every call is logged with tool name, status and
latency. `register_site_for_human` never creates a site record — it emails an
invite, and the human proves ownership by registering and installing the pixel.

## Observability

Every tool call writes one row (tool name, status, latency, `agent_id` when the
tool takes one). Aggregates are charted in Robauto's admin dashboard; the public
aggregate view is `https://robauto.ai/ai-search-data`.

## Deploying (maintainers)

The function source is generated from `src/lib/mcp/` in the app repo by the MCP
Vite plugin — never hand-edit the generated function. After changing a tool or
the server definition, regenerate the manifest and redeploy the `mcp` function.
