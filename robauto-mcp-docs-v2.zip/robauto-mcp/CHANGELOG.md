# Changelog

All notable changes to the Robauto MCP server. The authoritative tool contract is
`src/lib/mcp/catalog.ts` in the Robauto app; every file in this repo (README tool
table, `docs/manifest.json`, `docs/tools.md`) is generated from it. If a published
artifact disagrees with the live `tools/list` response, the live server wins and
the artifact is a bug — report it as one.

## Unreleased — documentation

Verified against a live `agent_scan` of `robauto.ai` and the live `tools/list` on
2026-09-06. The live tool list is 27 tools, exactly matching `docs/manifest.json`.

### Fixed

- **`docs/manifest.json` published invalid JSON Schema types.** Seven properties
  used TypeScript union/array syntax as a `type` string (`"'full' | 'basics'"`,
  `"string[]"`, `"('products'|'pricing'|…)[]"`). They are now proper
  `{"type":"string","enum":[…]}` and `{"type":"array","items":{…}}`. Affects
  `agent_scan.depth`, `get_network_data.view`, `get_ai_search_data.view`,
  `get_top_sites.sort`, `get_brand_contacts.department`, `compare_brands.criteria`
  and `compare_brands.domains`. **Fixed in the generator**, not only in the
  artifact: the catalog param type is now a JSON Schema primitive with optional
  `enum` / `items`, and a drift test fails if any published property type is not a
  valid JSON Schema type.
- **Docs pointed at `/openapi.yaml`.** The published document is
  `/openapi.json` (30 paths, confirmed by the `service_description` check).
  Corrected in `README.md` and `docs/mcp-server.md`.
- **`README.md` claimed every tool declares `readOnlyHint` / `destructiveHint` /
  `openWorldHint`.** The contract of record publishes `kind` instead and carries no
  annotations, so the claim was not backed by any artifact in this repo. Reworded to
  what is verifiable and listed under Known gaps.
- **`docs/review-access.md` said "no OAuth handshake"** without qualification, which
  read as a claim about the whole server. Scoped to the public endpoint, with the
  OAuth 2.1 owner-scoped surface described alongside it.

### Added

- **`get_site_agent_card` splits card from endpoint.** `mcp_endpoint` now returns
  only a callable JSON-RPC endpoint; the static server card moved to
  `mcp_server_card_url`.
- **RFC 8414 issuer-suffix discovery.** `/.well-known/oauth-authorization-server/auth/v1`
  and `/.well-known/openid-configuration/auth/v1` are now published as static
  documents instead of returning `404`.
- **Stale `force` guidance removed** from `agent_scan` / `get_site_agent_card` output.
- **Robauto's own brand record populated** — support route, policy links and all
  seven agent endpoints, each with the page it came from.
- **Known gaps** section in `README.md` — the open items from the audit, each with
  the evidence behind it: RFC 8414 issuer-suffix `404`, `mcp_endpoint` returning the
  server card instead of a callable endpoint, the stale `force` argument in
  `agent_scan` output, missing manifest annotations, Robauto's own thin brand record,
  and the `ai_referral` detection floor.
- **Live self-scan** section in `README.md` with a reproducible curl and the current
  result (98/100, 24 pass, 1 warn, 0 fail).
- Contract-stability table now records the date the tool list was last diffed
  against the live server.

### Notes — open, needs app-repo changes

- `get_site_agent_card.mcp_endpoint` returns `…/.well-known/mcp/server-card.json`.
  That is the card, not a callable MCP endpoint (`https://mcp.robauto.ai`). Agents
  that POST JSON-RPC to the advertised value get a static document.
- `get_site_agent_card.signal.note` tells callers to "call agent_scan with force";
  `force` is not in the live input schema (`domain`, `depth`, `include_fixes`).
- `robauto.ai` returns 0 contacts, 0 policies and 0 agent endpoints from its own
  index, while its scan confirms an A2A card, MCP server card, OpenAPI document,
  OAuth discovery and x402. Fixable with `submit_brand`, but each value must be
  sourced from its own `robauto.ai` page using the canonical field keys — not
  guessed here.

## 0.7.1 — 2026-09-06

### Added

- `get_brand_agent_endpoints` — the machine-to-machine entry points a brand publishes
  for agents: MCP server endpoint and manifest, agent card (A2A), ChatGPT/OpenAI
  connector, agent API docs (OpenAPI), agent auth discovery and agent payments
  endpoint. Values remain available regardless of age and retain their source
  URL and last-checked timestamp.
- `get_site_agent_card` now returns `agent_endpoints`, and prefers a published,
  sourced MCP / agent-card / connector URL over a live probe guess.

## 0.7.0 — 2026-09-06

### Added

- **`get_site_agent_card`** — one canonical object per domain: identity,
  description, declared products, contact routes, policies, capabilities
  (llms.txt, MCP server card, A2A agent card, agent payments), agent and MCP
  endpoints, payment methods, verification/freshness counts and readiness score.
  Replaces chaining `get_brand_profile` + `get_brand_contacts` +
  `get_brand_policies` + `get_brand_products`.
- **`ask_brand`** — a plain-language question answered strictly from that card,
  with the card and every `source_url` returned alongside the answer. Nothing
  outside the card is used; values retain source and last-checked metadata so
  callers can judge freshness.
- **`compare_brands`** — 2-5 domains diffed on products, pricing, policies,
  agent readiness, contacts and capabilities, plus a readiness ranking for the
  domains that have a score. Blank columns are left blank, never guessed.
- **`submit_brand`** — one write call adds a brand and every contact, opt-out
  and policy field at once (up to 20 domains per call). Each field must carry
  the page it was read from, on the brand's own domain. Values store as
  `submitted`, queue for a human check, and never overwrite a verified value.
  Same body over plain HTTP: `POST /functions/v1/brand-submit` (GET it for the
  schema).
- **`get_network_data`** — every Robauto network statistic behind one `view`
  parameter (`summary`, `top_sites`, `top_agents`, `boosts`, `featured`,
  `ai_search`).

### Changed

- **`agent_scan` now takes `depth`.** `depth: "basics"` runs the Signal Basics
  file checks only — what `signal_scan` did. One tool, one score, one vocabulary
  for checking a site.

### Deprecated

Aliases still respond; scheduled for removal 2027-03-01.

- `signal_scan` → `agent_scan` with `depth: "basics"`
- `get_ai_search_data`, `get_top_sites`, `get_top_agents`, `get_boost_feed`,
  `get_featured_brands` → `get_network_data` with the matching `view`

## 0.6.0 — 2026-09-05

### Added

- **Brand resolution index.** Five tools — `find_brands`, `get_brand_profile`,
  `get_brand_contacts`, `get_brand_policies`, `report_contact_outcome` — return
  support, dispute/chargeback, escalation, legal, unsubscribe/opt-out and policy
  routes per domain, each value with `source_url`, `verified_at`, `method`,
  `confidence` and `status`.
- **Freshness metadata.** Contact and policy values include source and checked
  timestamps. As of 0.7.1, values are no longer withheld based on age.
- **Report feedback loop.** Three distinct unflagged clients over at least 48
  hours mark a field disputed and queue it for human verification; resolution
  scores the reporting clients.
- **HTTP twins** for every profile: `/directory`, `/directory.json`,
  `/brand/{domain}` + `.json` + `.md` + `/llms.txt`, `/claim/{domain}`, `/connect`.

### Changed

- Field labels now come from one canonical map shared by the connector tools,
  the published HTTP profiles and the admin editor.

## 0.5.0 — 2026-08-30

### Added

- **OAuth 2.1 protected surface at `https://mcp.robauto.ai/auth`.** Owner-scoped
  tools (`whoami`, `list_my_sites`, `get_my_site_traffic`, `get_my_scan`) behind
  the Robauto authorization server, with dynamic client registration and RFC 9728
  protected-resource metadata (`401` + `WWW-Authenticate` challenge). Reads run
  under row-level security as the consenting account; tokens without a
  `client_id` claim (i.e. copied app sessions) are refused.
- The public endpoint stays unauthenticated and unchanged — the split is now
  described on every generated surface (server card, agent card, `ai.txt`,
  `llms.txt`, `llms-full.txt`, repo docs).

## 0.4.0 — 2026-08-30

### Fixed

- **Per-site shard `get_brand_content` advertised the wrong title.** The live
  `site-mcp` shard returned `title: "get_brand_products"` for `get_brand_content`
  and had lost its full description (the brand-scoped line was being used as the
  description). Both are corrected, and the description now disambiguates the tool
  from `get_brand_pages` and `get_brand_products` so agents select correctly.
- **`capabilities.tools.listChanged` documented as `true`.** The server is
  stateless with no session and never emits `notifications/tools/list_changed`;
  the live server reports `false`. Docs now match.
- **Shard tool list was incomplete.** Every surface said the shard exposes three
  tools; it exposes four — `get_brand_overview`, `get_brand_pages`,
  `get_brand_content`, `get_brand_products`.
- **Repo README pinned server version `0.3.0`** while the live server reported
  `0.4.0`. Both are now `0.4.0`.

### Notes

- `agent_scan` returns a `readiness_score` (0-100) from the 25 agent-readiness
  checks. That is a separate field from `signal_strength` (the file/HTTPS-level
  Signal Strength returned by `signal_scan`); neither is the deprecated
  `aeo_score` alias.
- Deprecated aliases still callable: `scan_site` and `aeo_scan` (both →
  `signal_scan`, removal 2026-10-01), plus the shard's older single-purpose names
  (`get_brand_profile`, `get_brand_rank`, `get_brand_summary`,
  `get_brand_key_facts`, `get_site_*` → `get_brand_overview`).

## 0.3.0

- Commerce tools `search_products` and `get_brand_products`, three-layer data
  model (`observed` / `declared` / `transactable`), brand agent-page publishing
  gate (200 / 404 / 410).
