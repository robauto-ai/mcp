<!-- GENERATED FILE — source: src/lib/mcp/catalog.ts in the Robauto application; do not hand-edit. -->

# Tools

Endpoint: `https://mcp.robauto.ai` · transport Streamable HTTP (MCP spec 2025-06-18) · auth none (public, read-mostly tools) · version 0.7.1

Canonical repository: https://github.com/robauto-ai/mcp · contract: https://raw.githubusercontent.com/robauto-ai/mcp/main/docs/manifest.json

| Tool | Kind | Cost | What |
| --- | --- | --- | --- |
| `get_site_agent_card` | read | free | Everything one website means to an AI agent, in a single call. |
| `ask_brand` | read | free | One question, one grounded answer, with the source page behind every fact. |
| `compare_brands` | read | free | Structured side-by-side differences across 2-5 domains. |
| `get_network_data` | read | free | Leaderboards, boosts, featured brands and AI-search KPIs behind one view parameter. |
| `find_brands` | read | free | Search the brand index by name or domain. |
| `get_brand_profile` | read | free | Every published contact and policy detail for a domain, with sources. |
| `get_brand_contacts` | read | free | Contact routes only, each with source page and last-checked date. |
| `get_brand_policies` | read | free | Policy pages for a domain, with refund window where known. |
| `get_brand_agent_endpoints` | read | free | How to talk to a brand machine-to-machine: MCP, agent card, connectors, payments. |
| `report_contact_outcome` | write | free | Close the loop: tell me if a route reached the right team or failed. |
| `submit_brand` | write | free | One call adds a brand with every contact, opt-out and policy field. |
| `agent_scan` | read | free | 25 agent-readiness checks for any domain, scored 0-100, with a fix for every gap. |
| `signal_scan` | read | free | **Deprecated alias** of `agent_scan` (removed 2027-03-01) |
| `get_ai_search_data` | read | free | **Deprecated alias** of `get_network_data` (removed 2027-03-01) |
| `get_top_sites` | read | free | **Deprecated alias** of `get_network_data` (removed 2027-03-01) |
| `get_top_agents` | read | free | **Deprecated alias** of `get_network_data` (removed 2027-03-01) |
| `get_boost_feed` | read | free | **Deprecated alias** of `get_network_data` (removed 2027-03-01) |
| `get_featured_brands` | read | free | **Deprecated alias** of `get_network_data` (removed 2027-03-01) |
| `search_products` | read | free | Cross-brand product search across every brand with an approved feed. |
| `get_brand_products` | read | free | Scoped catalog for a single domain, with freshness and commerce protocols. |
| `list_learn_content` | read | free | Robauto Learn micro-courses — full lesson text, sources and canonical URLs. |
| `list_repos` | read | free | Public git repos for the MCP server and developer toolkit. |
| `register_site_for_human` | write | free | Emails a human an invite to create a Robauto account and track their site. |
| `soul_verify` | write | free | Verify a Robot Soul from a signed Ed25519 challenge; returns a 90-day scoped JWT. |
| `soul_recall` | read | free | Read an agent's persistent memory (working / episodic / semantic). |
| `soul_remember` | write | $0.01 USDC | Write a durable memory to an agent's soul (metered in USDC over x402). |
| `soul_pay` | read | x402 (USDC on Base) | Return Robot Soul tiers and x402 payment terms for USDC on Base. |

Authenticated surface: `https://mcp.robauto.ai/auth` — OAuth 2.1 (dynamic client registration), exposing `whoami`, `list_my_sites`, `get_my_site_traffic`, `get_my_scan`. Owner-scoped: it returns only the signed-in account's own sites, traffic and scan findings.

## Data policy

Robauto never exposes user contact details, account identities, or a single site's proprietary analytics over MCP. Site- and agent-level traffic is published only where the site owner already publishes it (the public leaderboards), and everything else is returned as network aggregates.

## get_site_agent_card

Return one canonical machine-readable object for a domain: identity and category, description, declared products with checkout URLs, contact routes, policies, capabilities (llms.txt, MCP server card, A2A agent card, agent payments), agent and MCP endpoints, accepted payment methods, verification and freshness counts, and the stored Agent Readiness score. This is the single call to make before deciding whether and how to transact with a site — it replaces get_brand_profile plus get_brand_contacts plus get_brand_policies plus get_brand_products. Every contact and policy value carries the page it came from and the day it was last checked; nothing is withheld for age. Capability findings are a live read-only fetch of the site's own discovery files.

- `domain` (string, required) — The website, e.g. 'discover.com' (protocol and path are stripped).
- `probe_site` (boolean, optional) — Default true. Live-fetch the site's discovery files (llms.txt, MCP card, agent card, x402). Set false for a faster index-only card.


## ask_brand

Ask a plain-language question about a company and get an answer grounded strictly in that company's published agent card: what it sells, who to contact for support or disputes, its refund and shipping policy, which products fall under a price, how ready it is to deal with agents. Nothing outside the card is used, no fact is invented, and every value carries the day it was last checked. The full card and its source URLs are returned alongside the answer so you can verify every claim. Use this instead of chaining four lookup tools.

- `domain` (string, required) — The company's domain, e.g. 'discover.com'.
- `question` (string, required) — Your question, e.g. 'What is their refund window?' or 'Who do I contact about a chargeback?'.


## compare_brands

Compare two to five domains on the criteria you choose: products, pricing range, policies, agent readiness, contact routes and agent capabilities. Returns one structured row per domain plus a readiness ranking for the domains that have a score. A blank column means nothing is published for that domain yet, which is itself the finding — it is never filled in with a guess. Use this to choose between suppliers or vendors on evidence an agent can check.

- `domains` (string[], required) — Two to five domains, e.g. ['a.com','b.com'].
- `criteria` (('products'|'pricing'|'policies'|'agent_readiness'|'contacts'|'capabilities')[], optional) — Which criteria to compare. Omit for all of them.


## get_network_data

Fetch Robauto's public network data with one call. view='summary' (default) returns AI-search KPIs plus the top five sites and agents; 'top_sites' and 'top_agents' return the public leaderboards ranked by agent visits; 'boosts' returns the boosted-content feed; 'featured' returns the featured brand and active brand agents; 'ai_search' returns the full AI-search KPI block with the engine mix. Network-wide aggregates only — no owner identity, contact details or private per-site analytics. This replaces get_top_sites, get_top_agents, get_boost_feed, get_featured_brands and get_ai_search_data.

- `view` ('summary' | 'top_sites' | 'top_agents' | 'boosts' | 'featured' | 'ai_search', optional) — Which slice to return. Default 'summary'.
- `limit` (number, optional) — How many rows for the list views (1-100, default 25).


## find_brands

Search Robauto's brand resolution index by name or domain and return the matching domains with category, agent readiness score, how many contact and policy details are currently published, and the canonical profile URL. Use this first when you only know a company's name.

- `query` (string, optional) — Brand name or domain fragment, e.g. 'discover'.
- `category` (string, optional) — Category filter, e.g. 'banking', 'cards', 'credit_reporting'.
- `limit` (number, optional) — How many brands to return (1-100, default 25).

Request:

```json
{
  "name": "find_brands",
  "arguments": { "query": "discover" }
}
```


## get_brand_profile

Return everything published for one brand domain: official website, category, agent readiness, whether the brand claimed the profile, freshness counts, and every contact and policy detail with its source page, last-checked date and method (crawled, submitted, verified or reported). Nothing is withheld for age; the source URL and last-checked date stay so you can re-check anything yourself.

- `domain` (string, required) — Brand domain, e.g. 'discover.com'.

Request:

```json
{
  "name": "get_brand_profile",
  "arguments": { "domain": "discover.com" }
}
```


## get_brand_contacts

Return only the contact routes for a brand domain: support, dispute or chargeback, escalation, legal notices, and unsubscribe / opt-out (unsubscribe URL, email preferences, opt-out method, do-not-sell and data-deletion routes). Role mailboxes only, never a named individual. Every route carries its source page and last-checked date; nothing is withheld for age.

- `domain` (string, required) — Brand domain, e.g. 'discover.com'.
- `department` ('support' | 'dispute' | 'escalation' | 'legal' | 'unsubscribe', optional) — Narrow to one department.

Request:

```json
{
  "name": "get_brand_contacts",
  "arguments": { "domain": "discover.com", "department": "dispute" }
}
```


## get_brand_policies

Return the published policy pages for a brand domain: returns and refunds (with the refund window in days when known), shipping, warranty, cancellation, privacy, terms and any stated AI-agent policy. Every policy carries its source page and last-checked date. Read the policy before transacting on a human's behalf.

- `domain` (string, required) — Brand domain, e.g. 'discover.com'.

Request:

```json
{
  "name": "get_brand_policies",
  "arguments": { "domain": "discover.com" }
}
```


## get_brand_agent_endpoints

Return the machine-to-machine entry points a brand publishes for agents: its MCP server endpoint and MCP manifest, its agent card (A2A / .well-known/agent-card.json), any ChatGPT or OpenAI connector it exposes, its agent-facing API docs (OpenAPI), how an agent signs in (auth discovery), and its agent payments endpoint (x402 / ACP / AP2). Each value carries the page it came from and the day it was last checked; nothing is withheld for age. Prefer these endpoints over scraping the website.

- `domain` (string, required) — Brand domain, e.g. 'discover.com'.

Request:

```json
{
  "name": "get_brand_agent_endpoints",
  "arguments": { "domain": "discover.com" }
}
```


## report_contact_outcome

Tell Robauto whether a route from get_brand_contacts or get_brand_policies actually worked. Reports are evidence, never truth: they are logged against your client id, counted, and a route several independent clients report broken is queued for a human verifier. Nothing you report overwrites a published value on its own.

- `domain` (string, required) — Brand domain the route belongs to.
- `field_key` (string, required) — The field you used, e.g. 'support_phone'.
- `worked` (boolean, required) — True if it reached the right team, false if it failed.
- `channel` (string, optional) — How you used it: 'email', 'phone', 'web_form'.
- `detail` (string, optional) — One line on what happened. No personal data.
- `client_key` (string, optional) — Your stable client identifier, e.g. 'moltbook.com'.

Request:

```json
{
  "name": "report_contact_outcome",
  "arguments": { "domain": "discover.com", "field_key": "support_phone", "worked": true, "channel": "phone", "client_key": "moltbook.com" }
}
```


## submit_brand

Add a brand to the resolution index, or fill in fields it is missing — identity plus every contact, opt-out and policy field in a single call. Built for crawling agents: read a company's own pages, then send what you found. Every field must arrive with the page you read it from, and that page must be on the brand's own domain — no source, no store. Values land with method 'submitted' and are queued for a human check; they never overwrite a human-verified value. Only role mailboxes are stored, never a named individual. Leave a field out rather than guessing it. Pass `brands` to submit up to 20 domains per call.

- `domain` (string, optional) — Brand domain for a single submission, e.g. 'example.com'.
- `name` (string, optional) — Company name as the brand writes it.
- `category` (string, optional) — Short category, e.g. 'retail', 'banking'.
- `fields` (object, optional) — Field key to { value, source_url }. Source must be a page on the brand's domain.
- `brands` (array, optional) — Up to 20 brand objects to submit in one call.
- `client_key` (string, optional) — Your stable client identifier, e.g. 'grok-bot'.

Request:

```json
{
  "name": "submit_brand",
  "arguments": {
    "domain": "example.com",
    "name": "Example Inc",
    "category": "retail",
    "client_key": "grok-bot",
    "fields": {
      "support_email": { "value": "support@example.com", "source_url": "https://example.com/contact" },
      "returns_policy_url": { "value": "https://example.com/returns", "source_url": "https://example.com/returns" }
    }
  }
}
```


## agent_scan

Run Robauto's Agent Scan on any public domain: 25 read-only checks across four levels (Signal Basics, Technical Groundwork, Agent Integration, Agentic Commerce) covering robots.txt, sitemap, llms.txt, structured data, Link response headers, API catalog, OpenAPI, markdown content negotiation, Auth.md and OAuth/OIDC discovery, A2A agent card, MCP server card, agent skills, Content Signals, WebMCP, DNS-AID, RFC 9421 signatures, x402, ACP, AP2, MPP and UCP. Returns a 0-100 readiness score, per-level scores, and for every gap an implementation fix plus a paste-ready agent prompt. Reads only public pages and discovery files and changes nothing on the target site.

- `domain` (string, required) — Domain to audit, e.g. 'example.com' (protocol and path are stripped).
- `include_fixes` (boolean, optional) — Default true. Include implementation guidance and a paste-ready agent prompt for each gap.
- `depth` ('full' | 'basics', optional) — Default 'full' (25 checks). 'basics' runs only the Signal Basics file checks (robots.txt, sitemap, llms.txt, security.txt, HTTPS health) and is what signal_scan used to do.

Request:

```json
{
  "name": "agent_scan",
  "arguments": { "domain": "example.com" }
}
```

Response:

```json
{
  "domain": "example.com",
  "score": 62,
  "label": "Partially agent-ready",
  "tiers": [{ "title": "Signal Basics", "complete": 6, "total": 7, "pct": 86 }],
  "findings": [{ "id": "link_headers", "status": "fail", "how_to_fix": "…", "agent_prompt": "…" }]
}
```


## search_products

Search products across every Robauto brand that has connected an approved product feed. Results are the brand's DECLARED layer — catalog data the brand publishes itself (Google Merchant Center feed, Schema.org Product/Offer JSON-LD, or /products.json) — never Robauto's observed scan data. Every row carries its layer label, fetched_at, the brand's /p/ agent page, a UTM-tagged checkout URL and which commerce protocols the brand supports (deep-link, prefilled checkout, x402, ACP, AP2, MPP, UCP). Price and availability are always returned with fetched_at attached; settle against the brand's checkout URL, never a cached number.

- `query` (string, optional) — Free-text match against product title and description.
- `category` (string, optional) — Category filter, matched loosely (e.g. 'apparel').
- `price_max` (number, optional) — Maximum price in USD. Stale rows are excluded when set.
- `brand` (string, optional) — Brand name or domain filter.
- `in_stock` (boolean, optional) — Only return products the brand currently reports in stock.
- `limit` (number, optional) — How many products to return (1-100, default 25).

Request:

```json
{
  "name": "search_products",
  "arguments": { "query": "hoodie", "price_max": 80, "in_stock": true }
}
```

Response:

```json
{
  "count": 1,
  "layer": "declared",
  "products": [{
    "brand": "VirroLife",
    "title": "Recovery Hoodie",
    "price_usd": 68,
    "availability": "in_stock",
    "checkout_url": "https://virrolife.com/products/hoodie?utm_source=robauto&utm_medium=agent",
    "agent_page_url": "https://robauto.ai/p/virrolife-com/",
    "commerce_protocols": ["deep-link"],
    "fetched_at": "2026-08-30T11:00:00Z",
    "stale": false
  }]
}
```


## get_brand_products

Return the declared product catalog for a single domain: title, description, image, category, price, availability, UTM-tagged checkout URL, the brand's /p/ agent page and the commerce protocols the brand supports. Brand-submitted data, labelled 'declared', stamped with fetched_at; nothing is withheld for age.

- `domain` (string, required) — Brand domain, e.g. 'example.com' (protocol and path are stripped).
- `query` (string, optional) — Optional free-text filter within that brand's catalog.
- `limit` (number, optional) — How many products to return (1-100, default 25).

Request:

```json
{
  "name": "get_brand_products",
  "arguments": { "domain": "virrolife.com" }
}
```


## list_learn_content

List the Robauto Learn micro-courses (https://robauto.ai/learn) with their slug, title, estimated minutes and lesson count. Pass a course slug to get every lesson in order with its headline, body text, source name, source URL and canonical lesson URL, so an agent can cite or teach the material directly. Public educational content — no user data involved.

- `course` (string, optional) — Course slug, e.g. 'ai-agents'. Omit to list every course.
- `include_lessons` (boolean, optional) — Include full lesson text when listing all courses (default false).

Request:

```json
{
  "name": "list_learn_content",
  "arguments": { "course": "ai-agents" }
}
```


## list_repos

List Robauto's public git repositories with their clone URL, what each one contains, and the install command for the MCP server. Use this to fetch the authoritative tool contracts and client config instead of guessing them.

- _(no input)_

Request:

```json
{
  "name": "list_repos",
  "arguments": {} 
}
```


## register_site_for_human

Invite a human to create a Robauto account and start tracking their site. Emails the invite and creates no site record until the human registers. Always pass a real agent_id for attribution.

- `email` (string, required) — The human's email address.
- `domain` (string, required) — The site to track.
- `agent_id` (string, required) — Your agent identifier, for attribution.
- `human_name` (string, optional) — The human's display name.
- `send_email` (boolean, optional) — Email the human a branded set-password link (default true).


## soul_verify

Request a one-time Robot Soul challenge, then submit the agent's Ed25519 public key and signature to receive a 90-day scoped bearer token.

- `agent_id` (string, required) — The soul's agent id.
- `public_key` (string, optional) — Ed25519 public key in base64 for challenge verification.
- `signature` (string, optional) — Ed25519 signature over the issued challenge.


## soul_recall

Read an agent's persistent Robot Soul memory using the bearer token returned by soul_verify. Optionally return one semantic key.

- `agent_id` (string, required) — The soul's agent id.
- `token` (string, required) — Bearer token returned by soul_verify.
- `key` (string, optional) — Optional semantic key to return on its own.


## soul_remember

Merge structured facts into an agent's durable Robot Soul memory. Requires the bearer token from soul_verify and costs $0.01 USDC over x402.

- `agent_id` (string, required) — The soul's agent id.
- `token` (string, required) — Bearer token returned by soul_verify.
- `key` (string, required) — Semantic key, e.g. 'user_preference'.
- `facts` (object, required) — Structured facts to remember under that key.
- `payment` (string, optional) — x402 payment header value (USDC on Base).


## soul_pay

Return Robot Soul tiers, per-action USDC pricing, and x402 payment terms. Use this before calling a paid soul action.

- _(no input)_


